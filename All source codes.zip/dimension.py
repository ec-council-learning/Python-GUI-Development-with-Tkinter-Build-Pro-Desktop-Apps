import tkinter as tk

root = tk.Tk()
root.title("Dimension Measurement!")
root.minsize(300,200)


tk.Message(root,text="Dolor elit amet do magna veniam aliqua aute elit consequat qui. .", width="5m").pack()
tk.Message(root,text="Dolor elit amet do magna veniam aliqua aute elit consequat qui. Qui pariatur qui pariatur sunt culpa. Ullamco dolor nostrud do deserunt excepteur quis excepteur. Tempor reprehenderit adipisicing esse elit tempor proident.", width="5p",bg="#00ff55").pack()
root.mainloop()