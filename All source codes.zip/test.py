import tkinter as tk

root = tk.Tk()
root.title("My first Tkinter Application")
root.minsize(300,200)


root.mainloop()