import math
help(math.sin)